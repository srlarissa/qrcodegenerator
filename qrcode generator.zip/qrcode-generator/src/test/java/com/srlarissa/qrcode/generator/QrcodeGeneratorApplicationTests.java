package com.srlarissa.qrcode.generator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QrcodeGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
